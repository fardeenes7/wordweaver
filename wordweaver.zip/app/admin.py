from django.contrib import admin

# admin title settings

admin.site.site_header = "wordweaver Admin"
admin.site.site_title = "wordweaver Admin Portal"
admin.site.index_title = "Welcome to wordweaver Portal"
